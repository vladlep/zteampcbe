package configuration;

import java.util.Vector;

import chemicals.*;
import space.*;

public class Configuration {
	
	public static final int MvSpLengthOx = 10;
	public static final int MvSpLengthOy = 20;
	
	public static final int sleepTime = 600;
	
	public static final ChemicalEntity ACTINIUM = new Atom(Position.randomPosition(), "Ac", toV("666",3), toV("111",3));
	public static final ChemicalEntity ALUMINIUM = new Atom(Position.randomPosition(), "Al", toV("666",3), toV("111",3));
	public static final ChemicalEntity AMERICIUM = new Atom(Position.randomPosition(), "Am", toV("666",3), toV("111",3));
	public static final ChemicalEntity ANTIMONY = new Atom(Position.randomPosition(), "Sb", toV("666",3), toV("111",3));
	public static final ChemicalEntity ARGON = new Atom(Position.randomPosition(), "Ar", toV("666",3), toV("111",3));
	public static final ChemicalEntity ARSENIC = new Atom(Position.randomPosition(), "As", toV("666",3), toV("111",3));
	public static final ChemicalEntity ASTATINE = new Atom(Position.randomPosition(), "At", toV("666",3), toV("111",3));
	public static final ChemicalEntity BARIUM = new Atom(Position.randomPosition(), "Ba", toV("666",3), toV("111",3));
	public static final ChemicalEntity CARBON = new Atom(Position.randomPosition(), "C", toV("666",3), toV("111",3));
	public static final ChemicalEntity HYDROGEN = new Atom(Position.randomPosition(), "H", toV("666",3), toV("111",3));
	public static final ChemicalEntity OXYGEN = new Atom(Position.randomPosition(), "O", toV("666",3), toV("111",3));
	
	public static final ChemicalEntity[] allAtoms = {Configuration.ACTINIUM, Configuration.ALUMINIUM, Configuration.AMERICIUM,
													Configuration.ANTIMONY, Configuration.ARGON, Configuration.ARSENIC,
													Configuration.ASTATINE, Configuration.BARIUM, Configuration.CARBON,
													Configuration.HYDROGEN, Configuration.OXYGEN};
	
	
	public static void start(ChemicalEntity[] atoms) {
		
		for(int i = 0; i < atoms.length; i++) {
			atoms[i].start();
		}
	}
	
	private static Vector<Integer> toV(String str, int n)
    {
            Vector<Integer> vector = new Vector<Integer>();
            for (int i = 0; i < n; i++)
                    vector.add(Integer.valueOf(str.charAt(i) - '0'));
            return vector;
    }

}
