package configuration;

import chemicals.LayeredChemistryRules;
import space.MovementSpace;

public class Main 
{

	public static void main(String[] args) {
		
		/**
		 * Optionally: Set chemistry rules (default: RandomChemistryRules)
		 * 
		 * MovementSpace.getInstance().setChemistryRules(new ChemistryRules());
		 */
		
		//MovementSpace.getInstance().setChemistryRules(new LayeredChemistryRules());
		
		/**
		 * Start 
		 */
		Configuration.start(Configuration.allAtoms);
	}
}
