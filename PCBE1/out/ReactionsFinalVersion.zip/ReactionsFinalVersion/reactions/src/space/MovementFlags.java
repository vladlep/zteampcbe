package space;
import java.util.HashMap;

import chemicals.ChemicalEntity;

public class MovementFlags {
	
	private HashMap<ChemicalEntity, Boolean> canMove;
	
	public MovementFlags() {
		
		this.canMove = new HashMap<ChemicalEntity, Boolean>();
	}
	
	public synchronized void changeMoveFlag(ChemicalEntity ch, boolean flag) {
		
		this.canMove.put(ch, flag);
		notifyAll();
	}
	
	public synchronized boolean canMove(ChemicalEntity ch) {
		
		return this.canMove.get(ch);
	}

}
