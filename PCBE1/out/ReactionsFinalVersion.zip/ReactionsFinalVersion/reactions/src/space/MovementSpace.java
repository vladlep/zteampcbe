package space;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Vector;

import configuration.Configuration;


import chemicals.Atom;
import chemicals.ChemicalEntity;
import chemicals.ChemistryRules;
import chemicals.RandomChemistryRules;
import chemicals.Molecule;

public class MovementSpace {
	
	private Vector<Vector<ChemicalEntity>> space = null;
	private static MovementSpace instance = null;
	private int lengthOx;
	private int lengthOy;
	private static MovementFlags moveFlags;
	private ChemistryRules chemistryRules;

	private MovementSpace(int lengthOx, int lengthOy) {
		
		this.lengthOx = lengthOx;
		this.lengthOy = lengthOy;
		
		this.space = new Vector<Vector<ChemicalEntity>>(lengthOx);
		for (int i = 0; i < lengthOx; i++) {
			
			this.space.add(new Vector<ChemicalEntity>(lengthOy));
			for (int j=0; j< lengthOy; j++) {
				
				space.get(i).add(null);
			}
		}
		
		MovementSpace.moveFlags = new MovementFlags();
		this.chemistryRules = new RandomChemistryRules();
	}
	
	public static MovementSpace getInstance() {
		
		if(MovementSpace.instance == null) {
			
			MovementSpace.instance = new MovementSpace(Configuration.MvSpLengthOx, Configuration.MvSpLengthOy);
		}
		return MovementSpace.instance;
	}
	
	public static MovementFlags getMovementFlags() {
		
		return MovementSpace.moveFlags;
	}
	
	public void setChemistryRules(ChemistryRules rules) {
		
		this.chemistryRules = rules;
	}

	public synchronized Position moveInSpace(Position currentPosition,Position newPosition) {
		
		if(validPosition(newPosition)) {
			
			if (emptySpace(newPosition)) {

				space.get(newPosition.getX()).set(newPosition.getY(),	space.get(currentPosition.getX()).get(currentPosition.getY()));
				space.get(currentPosition.getX()).set(currentPosition.getY(),null);
				space.get(newPosition.getX()).get(newPosition.getY()).setCurrentPosition(newPosition);
				
				return newPosition; 	
			} else {
				
				ArrayList<ChemicalEntity> result;
								
				ChemicalEntity colider = space.get(currentPosition.getX()).get(currentPosition.getY());
				ChemicalEntity colided = space.get(newPosition.getX()).get(newPosition.getY());
				
				MovementSpace.moveFlags.changeMoveFlag(colider, false);
				MovementSpace.moveFlags.changeMoveFlag(colided, false);
				colider.stopThread();
				colided.stopThread();
				
				this.space.get(currentPosition.getX()).set(currentPosition.getY(), null);
				this.space.get(newPosition.getX()).set(newPosition.getY(), null);
				
				result = this.chemistryRules.colision(colided, colider);
				ChemicalEntity ch;
				Iterator<ChemicalEntity> it = result.iterator();
				while(it.hasNext()) {
					ch = it.next();
					if(ch instanceof Atom) {
						MovementSpace.moveFlags.changeMoveFlag(ch, true);
					}
					if(ch instanceof Molecule) {
						ch.start();
					}
				}
				
				return newPosition;	
			}
		}
		return null;
	}

	public synchronized void printSpace() {
		
		System.out.println("New space "+ space.size()+" "+space.get(1).size());
		System.out.println("__________________________________________________________________________________________________________");
		for (int i = 0; i < lengthOx; i++)
		{
			System.out.print("| ");
			for (int j = 0; j < lengthOy; j++) {
			
				if(space.get(i).get(j) == null) {
					System.out.print("   ");
				} else {
					System.out.print(space.get(i).get(j) + " ");
				}
			}
			System.out.println();
		}
		System.out.println("__________________________________________________________________________________________________________");


	}

	public synchronized boolean emptySpace(Position pos) {

		if(this.space.get(pos.getX()).get(pos.getY()) == null)
			return true;
		return false;
	}
	
	public boolean validPosition(Position p) {
		
		if(p.getX() >= this.lengthOx || p.getX() <0 )
			return false;
		if(p.getY() >= this.lengthOy || p.getY() <0 )
			return false;
		return true;
	}

	public synchronized void addChemicalEntity(ChemicalEntity chemicalEntity, Position currentPosition) {
		
		/*Position position;
		if(this.space.get(currentPosition.getX()).get(currentPosition.getY()) != chemicalEntity) {
			
			do {
				position = Position.randomPosition();
			} while(this.space.get(position.getX()).get(position.getY()) != chemicalEntity);
		} else {
			position = currentPosition;
		}
		this.space.get(position.getX()).set(position.getY(),chemicalEntity);*/
		this.space.get(currentPosition.getX()).set(currentPosition.getY(),chemicalEntity);
	}
}
