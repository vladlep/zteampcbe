package space;

import configuration.Configuration;

public class Position {

	private int x;
	private int y;
	
	public Position(int x, int y)
	{
		this.x = x;
		this.y = y;
	}
	
	public int getX() {
		return x;
	}
	
	public int getY() {
		return y;
	}
	
	public Position generatePosition() // shouldn't be sync?
	{
		Position newPosition ;
		do{
			int differenceOnX = (int) (Math.random() * 3 )- 1; // can be -1, 0 or 1
			int differenceOnY = (int) (Math.random() * 3 )- 1; // can be -1, 0 or 1
			newPosition = new Position(this.getX() + differenceOnX, 	this.getY() + differenceOnY);
		}while(this.equals(newPosition)); //shouldn't generate the same position 

		return newPosition;
	}
	
	public String toString() {
			return "x="+x+" y="+y;
	}
	
	public boolean equals(Object obj) {
		if( obj instanceof Position)
		 if(((Position)obj).x == this.x && ((Position)obj).y == this.y )
			 return true;
		return false;
	}
	
	public static synchronized Position randomPosition() {
		
		Position randPos;
		int x;
		int y;
		
		do {
			x = (int) (Math.random() * Configuration.MvSpLengthOx);
			y = (int) (Math.random() * Configuration.MvSpLengthOy);
			randPos = new Position(x, y);
		} while(!MovementSpace.getInstance().emptySpace(randPos));
			
		return randPos;
	}
}
