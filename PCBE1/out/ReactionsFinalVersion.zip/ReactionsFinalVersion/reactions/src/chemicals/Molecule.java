package chemicals;

import java.util.ArrayList;
import java.util.Vector;

import space.MovementSpace;
import space.Position;



public class Molecule extends ChemicalEntity {

	private Vector<ChemicalEntity> containedAtoms;

	public Molecule(Position currentPosition)
	{
		super(currentPosition);
		containedAtoms = new Vector<ChemicalEntity>();
	}

	public String toString() {
		
		String str= "";
		
		for ( int i = 0; i < this.containedAtoms.size(); i++) {
			
			if(this.containedAtoms.get(i) != null) {
				str = str + this.containedAtoms.get(i).toString();
			}
		}

		return str;
	}
	
	/**
	 *  - add the entity to molecule and stops it's thread. 
	 */
	public void addToMolecule(ChemicalEntity ch) {
		
		synchronized(MovementSpace.getMovementFlags()) {
			
			MovementSpace.getMovementFlags().changeMoveFlag(ch, false);
		}
		ch.setCurrentPosition(this.getCurrentPosition());
		containedAtoms.add(ch);
	}
	
	public synchronized void setCurrentPosition(Position newPosition) {
		
		super.setCurrentPosition(newPosition);
		for (int i =0; i<containedAtoms.size(); i++) {
			
			containedAtoms.get(i).setCurrentPosition(newPosition);
		}
	}

	@Override
	public ArrayList<ChemicalEntity> getComponents() {
		
		ArrayList<ChemicalEntity> components = new ArrayList<ChemicalEntity>();
		for(int i = 0; i < this.containedAtoms.size(); i++) {
			
			components.addAll(this.containedAtoms.get(i).getComponents());
		}
		
		return components;
	}
	
	public synchronized boolean setOccupied(int pos, int n)
    {
		for(ChemicalEntity ch: this.containedAtoms) {
			if(ch.setOccupied(pos, n) == true) {
				return true;
			}
		}
		return false;
    }
    
    public synchronized boolean unsetOccupied(int pos, int n)
    {
    	for(ChemicalEntity ch: this.containedAtoms) {
			if(ch.unsetOccupied(pos, n) == true) {
				return true;
			}
		}
		return false;
    }
	
	public synchronized int getForce()
    {
            int force = 0;
            for(ChemicalEntity a: this.containedAtoms) {
            	force += a.getForce();
            }
            return force;
    }
}
