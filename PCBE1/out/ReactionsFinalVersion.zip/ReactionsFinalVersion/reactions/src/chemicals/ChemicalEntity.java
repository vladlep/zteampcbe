package chemicals;
import java.util.ArrayList;

import configuration.Configuration;
import space.MovementSpace;
import space.Position;



public abstract class ChemicalEntity extends Thread {

	private Position currentPosition;
	private volatile boolean keepThreadAliveFlag = true;

	public ChemicalEntity(Position currentPosition) {
		
		this.currentPosition = currentPosition;
	}

	public void run() {
		
		MovementSpace.getInstance().addChemicalEntity(this, this.currentPosition);
		MovementSpace.getMovementFlags().changeMoveFlag(this, true);

		while (keepThreadAliveFlag) {

			synchronized (MovementSpace.getMovementFlags()) {

				while (!MovementSpace.getMovementFlags().canMove(this)) {
					try {
						MovementSpace.getMovementFlags().wait();
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
				
				Position newPosition = this.currentPosition.generatePosition();
				System.out.print(toString() + this.getId());
				Position retPosition = MovementSpace.getInstance().moveInSpace(this.currentPosition, newPosition);
				if(retPosition == null) {
					
					synchronized (MovementSpace.getInstance()) {
						System.out.println("couldn't move in space: "+newPosition.toString());
					}
				} else {
					
					synchronized (MovementSpace.getInstance()) {
						System.out.println(" moved to: "+retPosition.toString());
					}
					
					MovementSpace.getInstance().printSpace();
				}
			}	
				
			try {
				sleep(Configuration.sleepTime);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
	
	public void stopThread() {
		
		this.keepThreadAliveFlag = false;
	}
	
	public String toString() {

		return "("+currentPosition.getX()+","+currentPosition.getY()+")";
	}

	public synchronized void setCurrentPosition(Position newPosition) {
		
		this.currentPosition = new Position(newPosition.getX(), newPosition.getY());
	}
	
	public synchronized Position getCurrentPosition() {
		
		return new Position(this.currentPosition.getX(), this.currentPosition.getY());
	}

	public abstract ArrayList<ChemicalEntity> getComponents();
	
	public abstract boolean setOccupied(int pos, int n);
	
	public abstract boolean unsetOccupied(int pos, int n);
	
	public abstract int getForce();
}
