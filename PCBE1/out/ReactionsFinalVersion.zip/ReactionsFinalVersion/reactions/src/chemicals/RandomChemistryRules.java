package chemicals;

import java.util.ArrayList;

import space.MovementSpace;
import space.Position;



public class RandomChemistryRules implements ChemistryRules{
	
	public ArrayList<ChemicalEntity> colision(ChemicalEntity colided, ChemicalEntity colider) {
		
		ArrayList<ChemicalEntity> components = colided.getComponents();
		components.addAll(colider.getComponents());
		ArrayList<ChemicalEntity> result = new ArrayList<ChemicalEntity>();
		
		int count = components.size();
		synchronized(MovementSpace.getInstance()) {
			
			while(count != 0) {
				
				int rand = (int)(Math.random() * count) + 1;
				if(rand > 1) {
					Molecule newMolecule = new Molecule(Position.randomPosition());
					for(int i = 0; i < rand; i++) {
					
						int rand2 = (int) (Math.random() * count);
						newMolecule.addToMolecule(components.get(rand2));
						components.remove(rand2);
						count = components.size();
					}
					result.add(newMolecule);
					MovementSpace.getInstance().addChemicalEntity(newMolecule, newMolecule.getCurrentPosition());
				} else {
					int rand3 = (int) (Math.random() * count);
					components.get(rand3).setCurrentPosition(Position.randomPosition());
					result.add(components.get(rand3));
					components.remove(rand3);
					count = components.size();
					MovementSpace.getInstance().addChemicalEntity(result.get(result.size() - 1), result.get(result.size() - 1).getCurrentPosition());
				}
			}
		}
		
		return result;
	}

}
