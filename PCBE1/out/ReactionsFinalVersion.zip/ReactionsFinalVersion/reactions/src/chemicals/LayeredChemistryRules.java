package chemicals;

import java.util.ArrayList;

import space.MovementSpace;
import space.Position;

public class LayeredChemistryRules implements ChemistryRules {

	@Override
	public ArrayList<ChemicalEntity> colision(ChemicalEntity colided, ChemicalEntity colider) {
		
		ArrayList<ChemicalEntity> result = new ArrayList<ChemicalEntity>();
		synchronized(MovementSpace.getInstance()) {
		
		
		ArrayList<ChemicalEntity> colidedComponents = colided.getComponents();
		ArrayList<ChemicalEntity> coliderComponents = colider.getComponents();
		
		int colidedForce = colided.getForce();
		int coliderForce = colider.getForce();
		
		if(colidedForce <= coliderForce) {
		
			ArrayList<ChemicalEntity> toRemove = new ArrayList<ChemicalEntity>();
			if(colidedComponents.size() >= 2) {
				
				for(ChemicalEntity ch: colidedComponents) {
					if(ch.getForce() < colided.getForce()/colidedComponents.size()) {
						toRemove.add(ch);
					}
				}
				colidedComponents.removeAll(toRemove);
				
				if(colidedComponents.size() >= 2) {
					Molecule newMolecule = new Molecule(Position.randomPosition());
					for(ChemicalEntity ch: colidedComponents) {
						
						newMolecule.addToMolecule(ch);
					}
					for(ChemicalEntity out: toRemove) {
						newMolecule.unsetOccupied(0, ((Atom)out).getOccuppied().get(0));
						newMolecule.unsetOccupied(1, ((Atom)out).getOccuppied().get(1));
						newMolecule.unsetOccupied(2, ((Atom)out).getOccuppied().get(2));
					}
					result.add(newMolecule);
					MovementSpace.getInstance().addChemicalEntity(newMolecule, newMolecule.getCurrentPosition());
				} else {
					colidedComponents.get(0).setCurrentPosition(Position.randomPosition());
					result.add(colidedComponents.get(0));
					MovementSpace.getInstance().addChemicalEntity(result.get(result.size() - 1), result.get(result.size() - 1).getCurrentPosition());
				}
				
			} else {
				toRemove.add(colided);
			}
			
			ArrayList<ChemicalEntity> remaining = new ArrayList<ChemicalEntity>();
			
				for(ChemicalEntity ent: toRemove) {
					for(ChemicalEntity chEnt: coliderComponents) {
						if(((Atom)chEnt).combine((Atom)ent) == true) {
							remaining.add(ent);
							break;
						}
					}
				}
				
				coliderComponents.addAll(remaining);
				toRemove.removeAll(remaining);
				
				if(coliderComponents.size() >= 2) {
					Molecule newMolecule = new Molecule(Position.randomPosition());
					for(ChemicalEntity ch: coliderComponents) {
						
						newMolecule.addToMolecule(ch);
					}
					
					result.add(newMolecule);
					MovementSpace.getInstance().addChemicalEntity(newMolecule, newMolecule.getCurrentPosition());
				} else {
					coliderComponents.get(0).setCurrentPosition(Position.randomPosition());
					result.add(coliderComponents.get(0));
					MovementSpace.getInstance().addChemicalEntity(result.get(result.size() - 1), result.get(result.size() - 1).getCurrentPosition());
				}
				
				for(ChemicalEntity ch: toRemove) {
					ch.setCurrentPosition(Position.randomPosition());
					result.add(ch);
					MovementSpace.getInstance().addChemicalEntity(result.get(result.size() - 1), result.get(result.size() - 1).getCurrentPosition());
				}
				
				
				
				
		} else {
			
			ArrayList<ChemicalEntity> toRemove = new ArrayList<ChemicalEntity>();
			if(coliderComponents.size() >= 2) {
				
				for(ChemicalEntity ch: coliderComponents) {
					if(ch.getForce() < colider.getForce()/coliderComponents.size()) {
						toRemove.add(ch);
					}
				}
				coliderComponents.removeAll(toRemove);
				
				if(coliderComponents.size() >= 2) {
					Molecule newMolecule = new Molecule(Position.randomPosition());
					for(ChemicalEntity ch: coliderComponents) {
						
						newMolecule.addToMolecule(ch);
					}
					for(ChemicalEntity out: toRemove) {
						newMolecule.unsetOccupied(0, ((Atom)out).getOccuppied().get(0));
						newMolecule.unsetOccupied(1, ((Atom)out).getOccuppied().get(1));
						newMolecule.unsetOccupied(2, ((Atom)out).getOccuppied().get(2));
					}
					result.add(newMolecule);
					MovementSpace.getInstance().addChemicalEntity(newMolecule, newMolecule.getCurrentPosition());
				} else {
					coliderComponents.get(0).setCurrentPosition(Position.randomPosition());
					result.add(coliderComponents.get(0));
					MovementSpace.getInstance().addChemicalEntity(result.get(result.size() - 1), result.get(result.size() - 1).getCurrentPosition());
				}
				
			} else {
				toRemove.add(colided);
			}
			
			ArrayList<ChemicalEntity> remaining = new ArrayList<ChemicalEntity>();
			
				for(ChemicalEntity ent: toRemove) {
					for(ChemicalEntity chEnt: colidedComponents) {
						if(((Atom)chEnt).combine((Atom)ent) == true) {
							remaining.add(ent);
							break;
						}
					}
				}
				
				colidedComponents.addAll(remaining);
				toRemove.removeAll(remaining);
				
				if(colidedComponents.size() >= 2) {
					Molecule newMolecule = new Molecule(Position.randomPosition());
					for(ChemicalEntity ch: colidedComponents) {
						
						newMolecule.addToMolecule(ch);
					}
					
					result.add(newMolecule);
					MovementSpace.getInstance().addChemicalEntity(newMolecule, newMolecule.getCurrentPosition());
				} else {
					colidedComponents.get(0).setCurrentPosition(Position.randomPosition());
					result.add(colidedComponents.get(0));
					MovementSpace.getInstance().addChemicalEntity(result.get(result.size() - 1), result.get(result.size() - 1).getCurrentPosition());
				}
				
				for(ChemicalEntity ch: toRemove) {
					ch.setCurrentPosition(Position.randomPosition());
					result.add(ch);
					MovementSpace.getInstance().addChemicalEntity(result.get(result.size() - 1), result.get(result.size() - 1).getCurrentPosition());
				}
			
		}
		
		
		}
		return result;
	}

}
