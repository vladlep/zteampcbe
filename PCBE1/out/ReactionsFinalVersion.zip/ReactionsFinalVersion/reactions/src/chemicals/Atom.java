package chemicals;
import java.util.ArrayList;
import java.util.Vector;

import space.Position;


public class Atom extends ChemicalEntity {

	private String name;
	
	private final Vector<Integer> MaxLayer;
    private final Vector<Integer> OccLayer;
    private Vector<Integer> OccLayerNow;

	
	public  Atom(Position currentPosition, String name, Vector<Integer> MaxLayer, Vector<Integer> OccLayer)
	{
		super(currentPosition);
		this.name = name;
		
		this.MaxLayer = (Vector<Integer>) MaxLayer.clone();
        this.OccLayer = (Vector<Integer>) OccLayer.clone();
        this.OccLayerNow = (Vector<Integer>) OccLayer.clone();

	}
	
	public String toString() {
	
		return name+super.toString();

	}

	@Override
	public ArrayList<ChemicalEntity> getComponents() {
		
		ArrayList<ChemicalEntity> components = new ArrayList<ChemicalEntity>();
		components.add(this);
		return components;
	}
	
	public void stopThread() {
				
	}
	
	public Vector<Integer> getMax()
    {
            return (Vector<Integer>) this.MaxLayer.clone();
    }
    
    public Vector<Integer> getOccuppied()
    {
            return (Vector<Integer>) this.OccLayer.clone();
    }
    
    /*
     * Add in pos n.
     */
    public synchronized boolean setOccupied(int pos, int n)
    {
            if (OccLayerNow.get(pos) + n >= MaxLayer.get(pos))
                    return false;
            OccLayerNow.set(pos, OccLayerNow.get(pos) + n);
                    return true;
    }
    
    public synchronized boolean unsetOccupied(int pos, int n)
    {
            if (OccLayerNow.get(pos) - n < OccLayer.get(pos))
                    return false;
            OccLayerNow.set(pos, OccLayerNow.get(pos) - n);
                    return true;
    }
    /*
     * Return the force of the atom.
     */
    public synchronized int getForce()
    {
            int force = 0;
            int factor = OccLayerNow.size();
            for (int i = 0; i < OccLayerNow.size(); i++) {
            	
                    force += (factor*(MaxLayer.get(i) - OccLayerNow.get(i)));
                    factor--;
            }
            return force;
    }

    public synchronized boolean combine(Atom atom)
    {
            Vector<Integer> aux = new Vector<Integer>(OccLayer.size());
            for (int i = 0; i < OccLayer.size(); ++i)
            {
                    aux.add(i, OccLayerNow.get(i) + atom.OccLayerNow.get(i));
                    if ((aux.get(i) >= MaxLayer.get(i)) || (aux.get(i) >= atom.MaxLayer.get(i)))
                            return false;
            }
            copyVector(OccLayerNow, aux);
            copyVector(atom.OccLayerNow, aux);
            return true;
    }
    
    public void copyVector(Vector<Integer> src, Vector<Integer> org)
    {
            int size = src.size();
            for (int i = 0; i < size; i++)
                    src.add(i, org.get(i));
    }



}
