package chemicals;

import java.util.ArrayList;

public interface ChemistryRules {
	
	ArrayList<ChemicalEntity> colision(ChemicalEntity colided, ChemicalEntity colider);
}
